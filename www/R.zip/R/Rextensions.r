######################################################################
# Author: Valentin Wimmer
# Date:   22 March 2011
# Description:
# R file on "creating R extensions"
# for the workshop G�ttingen, 28/29 March 2011 
######################################################################


# wd
setwd("C:/research/WSGoettingen")

# define a simple function
# minor allele frequency for a marker matrix (codes 0/1/2)
# only use markers with less than 'miss' missing values
maf <-  function(geno,miss=0){
  select <- geno[ ,colMeans(is.na(geno)) < miss] 
  maf <- colMeans(geno,na.rm=TRUE)/2
  if (any(maf > 0.5)) stop("something went wrong")
  class(maf) <- "maf"
  return (maf)
}

# example
X <- matrix(sample(c(0,1,2,NA),replace=TRUE,size=200,prob=c(0.6,0.2,0.1,0.1)),nrow=20)
(mafX <- maf(X))

# make a R package skeleton
package.skeleton(name = "myPackage",list="maf")

# add new functions
# S3 summary method for class 'maf"
summary.maf <- function(x){
   ans <- list(min=min(x),mean=mean(x),max=max(x))
   class(ans) <- "summary.maf"
   ans
}

# S3 print method for class 'summary.maf"
print.summary.maf <- function(x){
    cat("Min  = ",x$min,"\n")
    cat("Mean = ",x$mean,"\n")
    cat("Max  = ",x$max,"\n")
}
# save as R-File in appropriate directory


# create documentation files
prompt(summary.maf)
prompt(print.summary.maf)
# move files to the appropriate directory


# build package from source code
system("R CMD build C:/research/WSGoettingen/myPackage")
system("R CMD INSTALL C:/research/WSGoettingen/myPackage")
library(myPackage)


 