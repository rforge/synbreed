######################################################################
# Author: Valentin Wimmer
# Date:   22 March 2011
# Description:
# R file on "creating a gpData object"
# for the workshop G�ttingen, 28/29 March 2011 
######################################################################


# create a gpData object from simulated QTLMAS Data (see Hollander et al. 2010)
# data downloaded on 2011 - 01 - 20 from http://www.computationalgenetics.se/QTLMAS08/QTLMAS/DATA.html
setwd("C:/research/WSGoettingen/data")
library(synbreed)

# read file TrueEBV.txt with pedigree, trait, and tbv
dat <- read.table("TrueEBV.txt",header=TRUE,stringsAsFactors=FALSE)
dim(dat)
#  5865    7

# pedigree
ped <- with(dat,create.pedigree(ID=id,Par1=sire,Par2=dam,gener=gen,sex=abs(sex-2)))
summary(ped)
#Number of 
#         individuals  5865 
#         males :  2778 , females :  3087 
#         Par 1 (sire)  90 
#         Par 2 (dam)   871 
#         generations  7 


# phenotypic data
pheno <- data.frame(trait=dat$Phenotype,row.names=dat$id)  
summary(pheno)
#     trait           
# Min.   :-5.4380546  
# 1st Qu.: 0.0003337  
# Median : 1.3670472  
# Mean   : 1.4054656  
# 3rd Qu.: 2.8515623  
# Max.   : 8.6679983 

# covar = tbv
covar <- data.frame(tbv=dat$GeneticValue,row.names=dat$id)

# genotypic data
geno <- read.table("genotype_cor.txt",header=FALSE,stringsAsFactors=FALSE)
dim(geno)
# 5865 12001

# haplotypes to genotypes
geno2 <- matrix(data=NA,nrow=nrow(geno),ncol=(ncol(geno)-1)/2)

# loop over all markers
# may take some seconds ...
for (j in 1:ncol(geno2)){
  # combine phased data to a genotype
  geno2[,j] <- paste(as.character(geno[,2*j]),as.character(geno[,2*j+1]),sep="")
}

dim(geno2)
#[1] 5865 6000

# create map
# 6 chromosomes with 1000 markers
# dist between adjacent markers = 0.1cM
chr <- rep(1:6,each=1000)
pos <- rep(seq(from=0,to=99.9,by=.1),times=6)
map <- data.frame(chr=chr,pos=pos)

# create gpData object
qtlMASdata <- create.gpData(pheno=pheno,geno=geno2,map=map,pedigree=ped,covar=covar,map.unit="cM")

# save
save("qtlMASdata",file="qtlMASdata.Rdata")

summary(qtlMASdata)
#object of class 'gpData' 
#covar 
#         No. of individuals 5865 
#                 phenotyped 5865 
#                  genotyped 5865 
#pheno 
#         No. of traits 1 
#
#    trait           
# Min.   :-5.4380546  
# 1st Qu.: 0.0003337  
# Median : 1.3670472  
# Mean   : 1.4054656  
# 3rd Qu.: 2.8515623  
# Max.   : 8.6679983  
#
#geno 
#         No. of markers 6000 
#         genotypes 22 12 21 11 
#         frequencies 0.308 0.194 0.194 0.305 
#         NA's 0 %
#map 
#         No. of mapped markers  6000 
#         No. of chromosomes     6 
#         markers per chromosome 1000 1000 1000 1000 1000 1000 
#pedigree 
#Number of 
#         individuals  5865 
#         males :  2778 , females :  3087 
#        Par 1 (sire)  90 
#         Par 2 (dam)   871 
#         generations  7 


