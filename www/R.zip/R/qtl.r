######################################################################
# Author: Valentin Wimmer
# Date:   22 March 2011
# Description:
# R file on "gateway to qtl mapping"
# for the workshop G�ttingen, 28/29 March 2011 
######################################################################


library(synbreed)

data(maize)

# convert to data class "cross"
maize.cross <- gpData2cross(codeGeno(maize))

summary(maize.cross)
plot(maize.cross)

# single QTL model
res <- scanone(maize.cross, chr=1, pheno.col=1)
plot(res)
summary(res)
#    chr  pos  lod
#M42   1 94.5 4.76




