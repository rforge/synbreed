######################################################################
# Author: Valentin Wimmer
# Date:   22 March 2011
# Description:
# R file on "use gpData objects"
# for the workshop G�ttingen, 28/29 March 2011 
######################################################################


# wd and libaries
setwd("C:/research/WSGoettingen/data")
library(synbreed)
library(regress)

# load data
load("qtlMASdata.Rdata")
summary(qtlMASdata)

# code genoytypes as number of copies of the minor allele, i.e. 0, 1, and 2
qtlMASdata <- codeGeno(qtlMASdata,label.heter=c("12","21"),maf=0.05,keep.identical=FALSE,verbose=TRUE)
# step 1 : No markers removed due to fraction of missing values 
# step 2 : Recoding alleles 
# step 5 : 288 marker(s) removed with maf < 0.05 
# step 6 : 1 duplicated marker(s) removed 
# step 7 : Restoring original data format 

qtlMASdata$info
#$map.unit
#[1] "cM"
#
#$codeGeno
#[1] TRUE


#===================================
# 1) descriptive analyses
#===================================

# maf 
maf <- colMeans(qtlMASdata$geno)/2
summary(maf)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.05047 0.22030 0.33280 0.31620 0.41990 0.49980 


# density of minor allele frequency:
plot(density(maf))

# marker distiution
plotGenMap(qtlMASdata,dense=TRUE)
summaryGenMap(qtlMASdata)
#   noM range    avDist maxDist minDist
#1 951  99.9 0.1051579     0.3     0.1
#2 952  99.9 0.1050473     0.3     0.1
#3 948  99.8 0.1053854     0.4     0.1
#4 966  99.9 0.1035233     0.3     0.1
#5 942  99.9 0.1061637     0.3     0.1
#6 952  99.8 0.1049422     0.4     0.1



#===================================
# 2) working with a gpData object
#===================================

# only use indidviduals from the last generation
sel1 <- qtlMASdata$pedigree$ID[qtlMASdata$pedigree$gener<max(qtlMASdata$pedigree$gener)]
gp1 <- discard.individuals(qtlMASdata,which=sel1) 
summary(gp1)

head(gp1$covar)
head(qtlMASdata$pedigree[qtlMASdata$pedigree$gener==6,])


# only use markers on chr1 with pos 20 cM
sel2 <- rownames(qtlMASdata$map[qtlMASdata$map$chr!=1 | qtlMASdata$map$pos>=20,])
gp2 <- discard.markers(gp1,which=sel2) 
summary(gp2)


#===================================
# 3) LD
#===================================

# only use subset of gp2 -> less time required
LDmatrix <- LDMap(gp2)
LDlist <- LDDist(gp2)
# LDlist <- LDDist(gp2,type="bars") # for stacked histogramms

# LD 
str(LDlist)
head(LDlist[[1]])
str(LDmatrix)

# LD between adjacent markers
plotNeighbourLD(LDmatrix, gp2)


# nls curve accorind to Hill and Weir (1988)
LDDist(gp2,type="nls")

