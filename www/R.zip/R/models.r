######################################################################
# Author: Valentin Wimmer
# Date:   22 March 2011
# Description:
# R file on "genomic prediction models"
# for the workshop G�ttingen, 28/29 March 2011 
######################################################################


# load pacakges
library(synbreed)
library(regress)
library(BLR)
library(party)

# with maize data
data(maize) 

#================================
# Estimation of relatedness
#================================

# according to pedigree
# same order?
all.equal(factor(maize$pedigree$ID),maize$covar$id)
A <- kin(maize,ret="add",DH=maize$covar$DH)            
# DH = TRUE -> F=1            
class(A)
summary(A)

# according to marker data
# using formula of Habier (2007)
U <- kin(codeGeno(maize),ret="realized")/4    # coding: 0,1,2
# denominator = 8 sum p_i(1-p_i) for DH lines
class(U)
summary(U)

# compare in a heatmap
AA <- A[maize$covar$genotyped,maize$covar$genotyped]
# S3 method "[ "for class relationshipMatrix
plot(AA)
x11()
plot(U)

plot(as.numeric(U),as.numeric(AA))

#===================================
# BLUP models
#===================================

#
y <- maize$pheno$Trait
tbv <- maize$covar$tbv[maize$covar$genotyped]


# animal model
mod1 <- regress(y~1,Vformula=~AA)

# G-BLUP
mod2 <- regress(y~1,Vformula=~U)

summary(mod1)
# Maximised Residual Log Likelihood is -3349.847 
#
#Linear Coefficients:
#             Estimate Std. Error
# (Intercept) 1179.535      2.883
#
#Variance Coefficients:
#             Estimate Std. Error
#          AA   10.712      4.530
#          In   70.269      4.182

summary(mod2)
# Maximised Residual Log Likelihood is -3223.837 
#
#Linear Coefficients:
#             Estimate Std. Error
# (Intercept) 1178.921      0.197
#
#Variance Coefficients:
#             Estimate Std. Error
#          U   106.100     14.716
#          In   48.578      2.287



cor(mod1$predicted,y)
#  0.5770398

cor(mod2$predicted,y)
#  0.7264322

cor(mod1$predicted,tbv)
# 0.58681

cor(mod2$predicted,tbv)
#  0.8563112



#====================================
# Machine Learning algorithms
#====================================

# gpData as a data.frame
maize.df <- gpData2data.frame(maize)

# random forest
forest <- cforest(Trait~.,data=maize.df,controls=cforest_control(ntree=200,mtry=250))

cor(predict(forest),y)
# 0.7473573

cor(predict(forest),tbv)
# 0.7568317



#====================================
# cross validation
#====================================

maize2 <-codeGeno(maize)
maize2$pheno <- data.frame(rownames(maize2$pheno),maize2$pheno[,1])
X <- matrix(rep(1,nrow(maize2$pheno)),ncol=1)
Z <- diag(nrow(maize2$pheno))


# for model 1
diag(A)<-diag(A)+0.0001 # to avoid singularities
cv.maize1 <- crossVal(maize2$pheno,X,Z,cov.matrix=list(AA),k=5,Rep=2,
            Seed=123,sampling="random",varComp=mod1$sigma,VC.est="commit")
            
summary(cv.maize1) 
# Object of class 'cvData' 
#
# 5 -fold cross validation with 2 replications 
#        Sampling:                random 
#        Variance components:     committed 
#        Number of random effects: 1 
#        Number of individuals:   1250  
#       Size of the TS:          250 -- 250  
#
#Results: 
#                      Min        Mean +- pooled SE       Max 
# Predictive ability:  0.1289     0.2229 +- 0.0022        0.3521 
# Bias:                0.5561     1.0203 +- 0.0228        1.8429 
#
#Seed start:  123 
#Seed replications: 
#[1] 28758 78831
     
            
# for model 2    
diag(U)<-diag(U)+0.00000001 # to avoid singularities
cv.maize2 <- crossVal(maize2$pheno,X,Z,cov.matrix=list(U),k=5,Rep=2,
            Seed=123,sampling="random",varComp=mod2$sigma,VC.est="commit")
                        
summary(cv.maize2)
#Object of class 'cvData' 
#
# 5 -fold cross validation with 2 replications 
#        Sampling:                random 
#        Variance components:     committed 
#        Number of random effects: 1 
#        Number of individuals:   1250  
#        Size of the TS:          250 -- 250  
#
#Results: 
#                      Min        Mean +- pooled SE       Max 
# Predictive ability:  0.4589     0.5287 +- 0.0079        0.5691 
# Bias:                0.8747     1.0061 +- 0.0253        1.1179 
#
#Seed start:  123 
#Seed replications: 
#[1] 28758 78831
            



                          