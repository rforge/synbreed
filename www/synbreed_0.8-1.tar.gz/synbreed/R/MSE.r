mse <- function(cvData,gpData,trait=1,repl=1){
    if(class(cvData) != "cvData") stop("object not of class 'cvData'")
    k <- cvData$k
    Rep <- cvData$Rep
    mse <- matrix(data=NA,nrow=k,ncol=Rep)
    for (i in 1:Rep){
      for(ii in 1:k){
         id.TS  <- cvData$id.TS[[i]][[ii]]
         y <- gpData$pheno[id.TS,trait,repl]
         yhat <- cvData$bu[id.TS,ii+(i-1)] + cvData$bu[1,ii+(i-1)]
         mse[ii,i] <- mean((y-yhat)^2) 
      }  
    }
    return(mse)
}